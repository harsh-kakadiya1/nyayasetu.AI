var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});

// netlify/functions/index.ts
import "dotenv/config";
import express from "express";
import serverless from "serverless-http";

// server/routes.ts
import { createServer } from "http";

// server/storage.ts
import { randomUUID } from "crypto";
var MemStorage = class {
  constructor() {
    this.users = /* @__PURE__ */ new Map();
    this.documents = /* @__PURE__ */ new Map();
    this.analyses = /* @__PURE__ */ new Map();
    this.chatMessages = /* @__PURE__ */ new Map();
  }
  async getUser(id) {
    return this.users.get(id);
  }
  async getUserByUsername(username) {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  async createUser(insertUser) {
    const id = randomUUID();
    const user = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  async createDocument(insertDocument) {
    const id = randomUUID();
    const document = {
      id,
      content: insertDocument.content,
      documentType: insertDocument.documentType || null,
      userId: insertDocument.userId || null,
      filename: insertDocument.filename || null,
      uploadedAt: /* @__PURE__ */ new Date()
    };
    this.documents.set(id, document);
    return document;
  }
  async getDocument(id) {
    return this.documents.get(id);
  }
  async getUserDocuments(userId) {
    return Array.from(this.documents.values()).filter(
      (doc) => doc.userId === userId
    );
  }
  async createAnalysis(insertAnalysis) {
    const id = randomUUID();
    const analysis = {
      id,
      documentId: insertAnalysis.documentId,
      summary: insertAnalysis.summary,
      riskLevel: insertAnalysis.riskLevel,
      keyTerms: insertAnalysis.keyTerms || null,
      riskItems: insertAnalysis.riskItems || null,
      clauses: insertAnalysis.clauses || null,
      recommendations: insertAnalysis.recommendations || null,
      wordCount: insertAnalysis.wordCount || null,
      processingTime: insertAnalysis.processingTime || null,
      createdAt: /* @__PURE__ */ new Date()
    };
    this.analyses.set(id, analysis);
    return analysis;
  }
  async getAnalysis(id) {
    return this.analyses.get(id);
  }
  async getAnalysisByDocumentId(documentId) {
    return Array.from(this.analyses.values()).find(
      (analysis) => analysis.documentId === documentId
    );
  }
  async createChatMessage(insertMessage) {
    const id = randomUUID();
    const message = {
      ...insertMessage,
      id,
      createdAt: /* @__PURE__ */ new Date()
    };
    this.chatMessages.set(id, message);
    return message;
  }
  async getChatMessages(analysisId) {
    return Array.from(this.chatMessages.values()).filter((msg) => msg.analysisId === analysisId).sort((a, b) => (a.createdAt?.getTime() || 0) - (b.createdAt?.getTime() || 0));
  }
};
var storage = new MemStorage();

// server/schema.ts
import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, json, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
var users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull()
});
var documents = pgTable("documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id"),
  filename: text("filename"),
  content: text("content").notNull(),
  documentType: text("document_type"),
  uploadedAt: timestamp("uploaded_at").defaultNow()
});
var analyses = pgTable("analyses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  documentId: varchar("document_id").notNull(),
  summary: text("summary").notNull(),
  riskLevel: text("risk_level").notNull(),
  keyTerms: json("key_terms"),
  riskItems: json("risk_items"),
  clauses: json("clauses"),
  recommendations: json("recommendations"),
  wordCount: integer("word_count"),
  processingTime: text("processing_time"),
  createdAt: timestamp("created_at").defaultNow()
});
var chatMessages = pgTable("chat_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  analysisId: varchar("analysis_id").notNull(),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  createdAt: timestamp("created_at").defaultNow()
});
var insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true
});
var insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
  uploadedAt: true
});
var insertAnalysisSchema = createInsertSchema(analyses).omit({
  id: true,
  createdAt: true
});
var insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  createdAt: true
});

// server/services/gemini.ts
import { GoogleGenerativeAI } from "@google/generative-ai";
console.log("\u{1F50D} Gemini API Key Status:", {
  present: !!process.env.GEMINI_API_KEY,
  length: process.env.GEMINI_API_KEY?.length || 0,
  startsWithAI: process.env.GEMINI_API_KEY?.startsWith("AIzaSy") || false
});
var genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");
async function analyzeDocument(content, documentType, language = "en") {
  const model = genAI.getGenerativeModel({ model: "gemini-2.5-pro" });
  const languageInstructions = {
    "en": "Respond in English with clear, jargon-free explanations.",
    "hi": "\u0939\u093F\u0902\u0926\u0940 \u092E\u0947\u0902 \u091C\u0935\u093E\u092C \u0926\u0947\u0902 \u0914\u0930 \u0915\u093E\u0928\u0942\u0928\u0940 \u0936\u092C\u094D\u0926\u091C\u093E\u0932 \u0915\u094B \u0938\u0930\u0932 \u092D\u093E\u0937\u093E \u092E\u0947\u0902 \u0938\u092E\u091D\u093E\u090F\u0902\u0964",
    "gu": "\u0A97\u0AC1\u0A9C\u0AB0\u0ABE\u0AA4\u0AC0\u0AAE\u0ABE\u0A82 \u0A9C\u0AB5\u0ABE\u0AAC \u0A86\u0AAA\u0ACB \u0A85\u0AA8\u0AC7 \u0A95\u0ABE\u0AA8\u0AC2\u0AA8\u0AC0 \u0AB6\u0AAC\u0ACD\u0AA6\u0A9C\u0ABE\u0AB3\u0AA8\u0AC7 \u0AB8\u0AB0\u0AB3 \u0AAD\u0ABE\u0AB7\u0ABE\u0AAE\u0ABE\u0A82 \u0AB8\u0AAE\u0A9C\u0ABE\u0AB5\u0ACB\u0964",
    "mr": "\u092E\u0930\u093E\u0920\u0940\u0924 \u0909\u0924\u094D\u0924\u0930 \u0926\u094D\u092F\u093E \u0906\u0923\u093F \u0915\u093E\u092F\u0926\u0947\u0936\u0940\u0930 \u0936\u092C\u094D\u0926\u091C\u093E\u0932 \u0938\u094B\u092A\u094D\u092F\u093E \u092D\u093E\u0937\u0947\u0924 \u0938\u092E\u091C\u093E\u0935\u0942\u0928 \u0938\u093E\u0902\u0917\u093E\u0964",
    "ta": "\u0BA4\u0BAE\u0BBF\u0BB4\u0BBF\u0BB2\u0BCD \u0BAA\u0BA4\u0BBF\u0BB2\u0BB3\u0BBF\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0B9A\u0B9F\u0BCD\u0B9F \u0BB5\u0BBE\u0BB0\u0BCD\u0BA4\u0BCD\u0BA4\u0BC8\u0B95\u0BB3\u0BC8 \u0B8E\u0BB3\u0BBF\u0BAF \u0BAE\u0BCA\u0BB4\u0BBF\u0BAF\u0BBF\u0BB2\u0BCD \u0BB5\u0BBF\u0BB3\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
    "bn": "\u09AC\u09BE\u0982\u09B2\u09BE\u09AF\u09BC \u0989\u09A4\u09CD\u09A4\u09B0 \u09A6\u09BF\u09A8 \u098F\u09AC\u0982 \u0986\u0987\u09A8\u09BF \u09AA\u09B0\u09BF\u09AD\u09BE\u09B7\u09BE\u0997\u09C1\u09B2\u09BF \u09B8\u09B9\u099C \u09AD\u09BE\u09B7\u09BE\u09AF\u09BC \u09AC\u09CD\u09AF\u09BE\u0996\u09CD\u09AF\u09BE \u0995\u09B0\u09C1\u09A8\u0964"
  };
  const systemPrompt = `You are a legal document analysis expert. Analyze the provided legal document and provide a comprehensive breakdown in JSON format.

Your analysis should include:
1. A plain-language summary with key terms extracted
2. Risk assessment with specific items flagged by severity
3. Key clauses broken down with original and simplified text
4. Actionable recommendations prioritized by importance

Focus on:
- Clear, jargon-free explanations
- Identifying unusual or potentially problematic terms
- Providing practical, actionable advice
- Risk assessment using "high", "medium", "low" levels

Language Instructions: ${languageInstructions[language] || languageInstructions["en"]}

Document type context: ${documentType || "auto-detect"}

Respond with valid JSON matching this structure:
{
  "summary": {
    "summary": "string",
    "keyTerms": {
      "employer": "string",
      "employee": "string", 
      "salary": "string",
      "startDate": "string",
      "probation": "string"
    },
    "documentType": "string"
  },
  "riskItems": [
    {
      "level": "high|medium|low",
      "title": "string",
      "description": "string",
      "section": "string"
    }
  ],
  "clauses": [
    {
      "title": "string",
      "originalText": "string",
      "simplifiedText": "string",
      "section": "string"
    }
  ],
  "recommendations": [
    {
      "priority": number,
      "title": "string", 
      "description": "string",
      "actionType": "review|negotiate|legal|clarify"
    }
  ],
  "wordCount": number,
  "riskLevel": "high|medium|low"
}`;
  try {
    console.log("\u{1F680} Starting Gemini analysis...");
    console.log("\u{1F4C4} Content length:", content.length);
    console.log("\u{1F30D} Language:", language);
    const maxRetries = 3;
    let lastError = null;
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        console.log(`\u{1F4DE} Gemini API attempt ${attempt}/${maxRetries}`);
        const result = await model.generateContent({
          contents: [{ role: "user", parts: [{ text: `${systemPrompt}

Document to analyze:

${content}` }] }],
          generationConfig: {
            responseMimeType: "application/json"
          }
        });
        console.log("\u2705 Gemini API call successful");
        const response = await result.response;
        const analysisText = response.text();
        console.log("\u{1F4DD} Response length:", analysisText?.length || 0);
        if (!analysisText) {
          throw new Error("Empty response from Gemini API");
        }
        console.log("\u{1F50D} Parsing JSON response...");
        const analysis = JSON.parse(analysisText);
        if (!analysis.summary || !analysis.riskItems || !analysis.clauses || !analysis.recommendations) {
          console.error("\u274C Invalid analysis structure:", {
            hasSummary: !!analysis.summary,
            hasRiskItems: !!analysis.riskItems,
            hasClauses: !!analysis.clauses,
            hasRecommendations: !!analysis.recommendations
          });
          throw new Error("Invalid analysis structure from Gemini API");
        }
        console.log("\u2705 Analysis completed successfully");
        return analysis;
      } catch (apiError) {
        lastError = apiError;
        if (apiError.message?.includes("overloaded") || apiError.message?.includes("503")) {
          console.warn(`\u26A0\uFE0F API overloaded on attempt ${attempt}/${maxRetries}`);
          if (attempt < maxRetries) {
            const delay = Math.pow(2, attempt) * 1e3;
            console.log(`\u23F3 Waiting ${delay}ms before retry...`);
            await new Promise((resolve) => setTimeout(resolve, delay));
            continue;
          }
        } else {
          throw apiError;
        }
      }
    }
    throw lastError || new Error("Failed to analyze document after multiple attempts");
  } catch (error) {
    console.error("\u274C Gemini analysis error:", error);
    if (error instanceof SyntaxError) {
      console.error("\u{1F4DD} JSON Parse Error - Raw response:", error.message);
    }
    throw new Error(`Failed to analyze document: ${error instanceof Error ? error.message : "Unknown error"}`);
  }
}
async function answerQuestion(documentContent, question, previousContext, language = "en") {
  const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });
  const languageInstructions = {
    "en": "Respond in English with clear, accessible language.",
    "hi": "\u0939\u093F\u0902\u0926\u0940 \u092E\u0947\u0902 \u091C\u0935\u093E\u092C \u0926\u0947\u0902 \u0914\u0930 \u0938\u094D\u092A\u0937\u094D\u091F, \u0938\u0941\u0932\u092D \u092D\u093E\u0937\u093E \u0915\u093E \u0909\u092A\u092F\u094B\u0917 \u0915\u0930\u0947\u0902\u0964",
    "gu": "\u0A97\u0AC1\u0A9C\u0AB0\u0ABE\u0AA4\u0AC0\u0AAE\u0ABE\u0A82 \u0A9C\u0AB5\u0ABE\u0AAC \u0A86\u0AAA\u0ACB \u0A85\u0AA8\u0AC7 \u0AB8\u0ACD\u0AAA\u0AB7\u0ACD\u0A9F, \u0AB8\u0AC1\u0AB2\u0AAD \u0AAD\u0ABE\u0AB7\u0ABE\u0AA8\u0ACB \u0A89\u0AAA\u0AAF\u0ACB\u0A97 \u0A95\u0AB0\u0ACB\u0964",
    "mr": "\u092E\u0930\u093E\u0920\u0940\u0924 \u0909\u0924\u094D\u0924\u0930 \u0926\u094D\u092F\u093E \u0906\u0923\u093F \u0938\u094D\u092A\u0937\u094D\u091F, \u0938\u0941\u0932\u092D \u092D\u093E\u0937\u0947\u091A\u093E \u0935\u093E\u092A\u0930 \u0915\u0930\u093E\u0964",
    "ta": "\u0BA4\u0BAE\u0BBF\u0BB4\u0BBF\u0BB2\u0BCD \u0BAA\u0BA4\u0BBF\u0BB2\u0BB3\u0BBF\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0BA4\u0BC6\u0BB3\u0BBF\u0BB5\u0BBE\u0BA9, \u0B85\u0BA3\u0BC1\u0B95\u0B95\u0BCD\u0B95\u0BC2\u0B9F\u0BBF\u0BAF \u0BAE\u0BCA\u0BB4\u0BBF\u0BAF\u0BC8\u0BAA\u0BCD \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BB5\u0BC1\u0BAE\u0BCD.",
    "bn": "\u09AC\u09BE\u0982\u09B2\u09BE\u09AF\u09BC \u0989\u09A4\u09CD\u09A4\u09B0 \u09A6\u09BF\u09A8 \u098F\u09AC\u0982 \u09B8\u09CD\u09AA\u09B7\u09CD\u099F, \u09B8\u09C1\u09B2\u09AD \u09AD\u09BE\u09B7\u09BE \u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0 \u0995\u09B0\u09C1\u09A8\u0964"
  };
  const systemPrompt = `You are a legal document assistant. Answer questions about the provided legal document using only the information contained within it.

Rules:
- Base your answers solely on the document content
- If information isn't in the document, clearly state that
- Provide specific references to sections or clauses when possible
- Use clear, accessible language
- Keep responses concise but comprehensive

Language Instructions: ${languageInstructions[language] || languageInstructions["en"]}

${previousContext ? `Previous conversation context:
${previousContext}

` : ""}

Document content:
${documentContent}

Question: ${question}`;
  try {
    const maxRetries = 3;
    let lastError = null;
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        console.log(`\u{1F4DE} QA API attempt ${attempt}/${maxRetries}`);
        const result = await model.generateContent(systemPrompt);
        const response = await result.response;
        const answer = response.text();
        if (!answer) {
          throw new Error("Empty response from Gemini API");
        }
        console.log("\u2705 QA response received successfully");
        return answer;
      } catch (apiError) {
        lastError = apiError;
        if (apiError.message?.includes("overloaded") || apiError.message?.includes("503")) {
          console.warn(`\u26A0\uFE0F QA API overloaded on attempt ${attempt}/${maxRetries}`);
          if (attempt < maxRetries) {
            const delay = Math.pow(2, attempt - 1) * 1e3;
            console.log(`\u23F3 Waiting ${delay}ms before QA retry...`);
            await new Promise((resolve) => setTimeout(resolve, delay));
            continue;
          }
        } else {
          throw apiError;
        }
      }
    }
    throw lastError || new Error("Failed to answer question after multiple attempts");
  } catch (error) {
    console.error("Gemini Q&A error:", error);
    throw new Error(`Failed to answer question: ${error instanceof Error ? error.message : "Unknown error"}`);
  }
}

// server/services/documentParser.ts
import * as path from "path";
import * as mammoth from "mammoth";
async function parseTextBuffer(buffer, filename) {
  try {
    const content = buffer.toString("utf-8");
    const wordCount = content.trim().split(/\s+/).length;
    return {
      content: content.trim(),
      wordCount,
      filename
    };
  } catch (error) {
    throw new Error(`Failed to parse text file: ${error instanceof Error ? error.message : "Unknown error"}`);
  }
}
async function parseDocxBuffer(buffer, filename) {
  try {
    const result = await mammoth.extractRawText({ buffer });
    const content = result.value.trim();
    if (!content) {
      throw new Error("No text content found in DOCX file.");
    }
    const wordCount = content.split(/\s+/).length;
    return {
      content,
      wordCount,
      filename
    };
  } catch (error) {
    throw new Error(`Failed to parse DOCX file: ${error instanceof Error ? error.message : "Unknown error"}`);
  }
}
async function parsePdfBuffer(buffer, filename) {
  try {
    const pdfParse = __require("pdf-parse");
    const data = await pdfParse(buffer);
    const content = data.text.trim();
    if (!content) {
      throw new Error("No text content found in PDF file. The PDF might be image-based or encrypted.");
    }
    const wordCount = content.split(/\s+/).length;
    return {
      content,
      wordCount,
      filename
    };
  } catch (error) {
    throw new Error(`Failed to parse PDF file: ${error instanceof Error ? error.message : "Unknown error"}`);
  }
}
async function parseUploadedDocument(file) {
  const extension = path.extname(file.originalname).toLowerCase();
  try {
    switch (extension) {
      case ".txt":
        return await parseTextBuffer(file.buffer, file.originalname);
      case ".docx":
        return await parseDocxBuffer(file.buffer, file.originalname);
      case ".pdf":
        return await parsePdfBuffer(file.buffer, file.originalname);
      default:
        throw new Error(`Unsupported file type: ${extension}. Please use PDF, DOCX, or TXT files.`);
    }
  } catch (error) {
    throw error;
  }
}
function parseTextContent(text2) {
  const content = text2.trim();
  const wordCount = content.split(/\s+/).length;
  if (!content) {
    throw new Error("Document content is empty");
  }
  if (wordCount < 10) {
    throw new Error("Document is too short for meaningful analysis");
  }
  return {
    content,
    wordCount
  };
}

// server/routes.ts
import multer from "multer";
import path2 from "path";
var upload = multer({
  storage: multer.memoryStorage(),
  // Store in memory instead of disk
  limits: {
    fileSize: 15 * 1024 * 1024
    // 15MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [".pdf", ".docx", ".txt"];
    const ext = path2.extname(file.originalname).toLowerCase();
    if (allowedTypes.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type. Only PDF, DOCX, and TXT files are allowed."));
    }
  }
});
async function registerRoutes(app2) {
  app2.get("/", (req, res) => {
    res.json({
      message: "NyayaSetu API Server is running!",
      status: "healthy",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      endpoints: [
        "POST /api/documents/upload",
        "POST /api/documents/analyze-text",
        "GET /api/analysis/:id/messages",
        "POST /api/analysis/:id/chat"
      ]
    });
  });
  app2.get("/health", (req, res) => {
    res.json({ status: "healthy", timestamp: (/* @__PURE__ */ new Date()).toISOString() });
  });
  app2.post("/api/documents/upload", upload.single("document"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }
      const { documentType, summaryLength } = req.body;
      const language = req.headers["accept-language"] || "en";
      const parsedDoc = await parseUploadedDocument(req.file);
      const documentData = insertDocumentSchema.parse({
        userId: null,
        // Anonymous for now
        filename: req.file.originalname,
        content: parsedDoc.content,
        documentType: documentType || "auto-detect"
      });
      const document = await storage.createDocument(documentData);
      const startTime = Date.now();
      const analysis = await analyzeDocument(parsedDoc.content, documentType, language);
      const processingTime = `${((Date.now() - startTime) / 1e3).toFixed(1)} seconds`;
      const analysisData = insertAnalysisSchema.parse({
        documentId: document.id,
        summary: analysis.summary.summary,
        riskLevel: analysis.riskLevel,
        keyTerms: analysis.summary.keyTerms,
        riskItems: analysis.riskItems,
        clauses: analysis.clauses,
        recommendations: analysis.recommendations,
        wordCount: analysis.wordCount,
        processingTime
      });
      const savedAnalysis = await storage.createAnalysis(analysisData);
      res.json({
        document,
        analysis: {
          ...savedAnalysis,
          summary: analysis.summary,
          riskItems: analysis.riskItems,
          clauses: analysis.clauses,
          recommendations: analysis.recommendations
        }
      });
    } catch (error) {
      console.error("Document upload error:", error);
      res.status(500).json({
        error: error instanceof Error ? error.message : "Failed to process document"
      });
    }
  });
  app2.post("/api/documents/analyze-text", async (req, res) => {
    try {
      const { content, documentType, summaryLength, language } = req.body;
      const preferredLanguage = language || req.headers["accept-language"] || "en";
      if (!content || typeof content !== "string") {
        return res.status(400).json({ error: "Document content is required" });
      }
      const parsedDoc = parseTextContent(content);
      const documentData = insertDocumentSchema.parse({
        userId: null,
        // Anonymous for now
        filename: null,
        content: parsedDoc.content,
        documentType: documentType || "auto-detect"
      });
      const document = await storage.createDocument(documentData);
      const startTime = Date.now();
      const analysis = await analyzeDocument(parsedDoc.content, documentType, preferredLanguage);
      const processingTime = `${((Date.now() - startTime) / 1e3).toFixed(1)} seconds`;
      const analysisData = insertAnalysisSchema.parse({
        documentId: document.id,
        summary: analysis.summary.summary,
        riskLevel: analysis.riskLevel,
        keyTerms: analysis.summary.keyTerms,
        riskItems: analysis.riskItems,
        clauses: analysis.clauses,
        recommendations: analysis.recommendations,
        wordCount: analysis.wordCount,
        processingTime
      });
      const savedAnalysis = await storage.createAnalysis(analysisData);
      res.json({
        document,
        analysis: {
          ...savedAnalysis,
          summary: analysis.summary,
          riskItems: analysis.riskItems,
          clauses: analysis.clauses,
          recommendations: analysis.recommendations
        }
      });
    } catch (error) {
      console.error("Text analysis error:", error);
      res.status(500).json({
        error: error instanceof Error ? error.message : "Failed to analyze document"
      });
    }
  });
  app2.get("/api/analysis/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const analysis = await storage.getAnalysis(id);
      if (!analysis) {
        return res.status(404).json({ error: "Analysis not found" });
      }
      res.json(analysis);
    } catch (error) {
      console.error("Get analysis error:", error);
      res.status(500).json({ error: "Failed to retrieve analysis" });
    }
  });
  app2.post("/api/analysis/:id/question", async (req, res) => {
    try {
      const { id } = req.params;
      const { question, language } = req.body;
      const preferredLanguage = language || req.headers["accept-language"] || "en";
      if (!question || typeof question !== "string") {
        return res.status(400).json({ error: "Question is required" });
      }
      const analysis = await storage.getAnalysis(id);
      if (!analysis) {
        return res.status(404).json({ error: "Analysis not found" });
      }
      const document = await storage.getDocument(analysis.documentId);
      if (!document) {
        return res.status(404).json({ error: "Document not found" });
      }
      const previousMessages = await storage.getChatMessages(id);
      const context = previousMessages.map((msg) => `Q: ${msg.question}
A: ${msg.answer}`).join("\n\n");
      const answer = await answerQuestion(document.content, question, context, preferredLanguage);
      const messageData = insertChatMessageSchema.parse({
        analysisId: id,
        question,
        answer
      });
      const savedMessage = await storage.createChatMessage(messageData);
      res.json(savedMessage);
    } catch (error) {
      console.error("Q&A error:", error);
      res.status(500).json({
        error: error instanceof Error ? error.message : "Failed to answer question"
      });
    }
  });
  app2.get("/api/analysis/:id/messages", async (req, res) => {
    try {
      const { id } = req.params;
      const messages = await storage.getChatMessages(id);
      res.json(messages);
    } catch (error) {
      console.error("Get messages error:", error);
      res.status(500).json({ error: "Failed to retrieve messages" });
    }
  });
  const httpServer = createServer(app2);
  return httpServer;
}

// netlify/functions/index.ts
var app = express();
app.use((req, res, next) => {
  const allowedOrigins = [
    "http://localhost:3000",
    "http://localhost:5173",
    "https://nyayasetu-ai.netlify.app",
    "https://amazing-platypus-1c5e9f.netlify.app",
    "https://nyaya-setu-ai.netlify.app"
    // Add your actual Netlify URL here when you get it
  ];
  const origin = req.headers.origin;
  if (allowedOrigins.includes(origin)) {
    res.header("Access-Control-Allow-Origin", origin);
  }
  res.header("Access-Control-Allow-Credentials", "true");
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization, Accept-Language");
  if (req.method === "OPTIONS") {
    res.sendStatus(200);
  } else {
    next();
  }
});
app.use(express.json({ limit: "15mb" }));
app.use(express.urlencoded({ extended: false, limit: "15mb" }));
registerRoutes(app);
app.use((err, _req, res, _next) => {
  const status = err.status || err.statusCode || 500;
  const message = err.message || "Internal Server Error";
  res.status(status).json({ message });
});
var handler = serverless(app);
export {
  handler
};
